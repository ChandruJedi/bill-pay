package com.cognizant.paymentdetailsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.paymentdetailsservice.model.Payment;
import com.cognizant.paymentdetailsservice.service.PaymentService;

@RestController
@RequestMapping("/payment-gateway")
public class PaymentController {
	@Autowired PaymentService paymentService;
	@GetMapping("/{userId}/{billType}")
	public Payment billDetails(@PathVariable String userId, @PathVariable String billType) {
		return paymentService.billDetails(userId, billType);
	}
	@PostMapping("/{userId}")
	public void saveBillDetail(@PathVariable String userId, @RequestBody Payment detail) {
		paymentService.saveBillDetail(userId, detail);
	}
}
