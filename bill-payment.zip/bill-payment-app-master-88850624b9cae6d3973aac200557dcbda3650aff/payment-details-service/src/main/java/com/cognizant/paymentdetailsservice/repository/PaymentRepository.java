package com.cognizant.paymentdetailsservice.repository;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.paymentdetailsservice.model.Payment;
import com.cognizant.paymentdetailsservice.model.User;

@Repository
public interface PaymentRepository extends JpaRepository<Payment,Integer> {
	@Query("select u.paymentDetails FROM User u INNER JOIN u.paymentDetails p WHERE u.userId=:userId AND p.name=:billName")
	Payment billDetails(@PathParam("userId") String userId,@PathParam("billName") String billName);
	
	Payment findByNumber(String number);

}
