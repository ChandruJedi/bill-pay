package com.cognizant.paymentdetailsservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.paymentdetailsservice.model.Payment;
import com.cognizant.paymentdetailsservice.model.User;
import com.cognizant.paymentdetailsservice.repository.PaymentRepository;
import com.cognizant.paymentdetailsservice.repository.UserRepository;

@Service
public class PaymentService {
	@Autowired PaymentRepository paymentRepository;
	@Autowired UserRepository userRepository;
	@Transactional
	public Payment billDetails(String userId, String billName) {
		return paymentRepository.billDetails(userId, billName);
	}
	@Transactional
	public void saveBillDetail(String userId, Payment detail) {
		paymentRepository.save(detail);
		Payment bill = paymentRepository.findByNumber(detail.getNumber());
		System.out.println(bill);
		User user = userRepository.findByUserId(userId);
		System.out.println(user);
		List<Payment> detailList = user.getPaymentDetails();
		System.out.println(detailList);
		detailList.add(bill);
		user.setPaymentDetails(detailList);
		userRepository.save(user);
		System.out.println(user.getPaymentDetails());
	}
}
