package com.cognizant.paymentdetailsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentDetailsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentDetailsServiceApplication.class, args);
	}

}
