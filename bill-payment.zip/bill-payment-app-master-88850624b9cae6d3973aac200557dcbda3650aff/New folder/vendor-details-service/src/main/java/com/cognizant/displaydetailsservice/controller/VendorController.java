package com.cognizant.displaydetailsservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vendordetailsservice.model.Vendor;
import com.cognizant.vendordetailsservice.repository.UserRepository;
import com.cognizant.vendordetailsservice.service.VendorService;

@RestController
@RequestMapping("/admin/vendors")
public class VendorController {
	private static final Logger LOGGER = LoggerFactory.getLogger(VendorController.class);
	@Autowired UserRepository userRepository;
//	private User user;
	@Autowired
	private VendorService vendorService;
	
//	@Autowired
//	private AppUserDetailsService appUserDetailsService;
	
	@GetMapping
	public List<Vendor> getInActiveVendor() {
		LOGGER.debug("inside the getinactive method in admin controller");
//		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		User role = userRepository.findByUserId(user.getRole());
//		LOGGER.debug(role.toString());
		return vendorService.getInActiveVendor();

		
	}
	@PostMapping
	public void setVendor(@RequestBody @Valid Vendor vendor){
		vendorService.setVendor(vendor);
	}
	
}
