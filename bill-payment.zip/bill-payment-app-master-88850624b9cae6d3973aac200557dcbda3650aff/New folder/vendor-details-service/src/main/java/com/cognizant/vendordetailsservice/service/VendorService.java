package com.cognizant.vendordetailsservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.vendordetailsservice.model.Vendor;
import com.cognizant.vendordetailsservice.repository.VendorRepository;

@Service
public class VendorService {
	private static final Logger LOGGER = LoggerFactory.getLogger(VendorService.class);
	@Autowired
	private VendorRepository vendorRepositry;

//	public void register(Vendor vendor) {
//		// TODO Auto-generated method stub
//		vendorRepositry.save(vendor);
//	}
	
	public List<Vendor> getInActiveVendor() {
		LOGGER.debug("Inside the getinactivevendor method of vendorservice");
		return vendorRepositry.findByActive(false);
	}
	public void setVendor(Vendor vendor) {
		vendorRepositry.save(vendor);
	}
}
