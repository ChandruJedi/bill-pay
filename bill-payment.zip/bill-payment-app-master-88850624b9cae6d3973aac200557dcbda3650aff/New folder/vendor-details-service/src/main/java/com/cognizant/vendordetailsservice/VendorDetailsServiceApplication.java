package com.cognizant.vendordetailsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendorDetailsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendorDetailsServiceApplication.class, args);
	}

}
