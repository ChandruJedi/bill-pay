package com.cognizant.signup.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.signup.model.Vendor;
import com.cognizant.signup.repository.VendorRepository;

@Service
public class VendorService {
	@Autowired
	private VendorRepository vendorRepositry;
@Transactional
	public void register(Vendor vendor) {
		// TODO Auto-generated method stub
		vendorRepositry.save(vendor);
	}

}
