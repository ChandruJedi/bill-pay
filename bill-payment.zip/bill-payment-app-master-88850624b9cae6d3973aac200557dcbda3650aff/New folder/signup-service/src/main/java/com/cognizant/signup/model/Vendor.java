package com.cognizant.signup.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "vendor")
public class Vendor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ve_id")
	private int id;
	@Column(name = "ve_user_id")
	private String userId;
	@Column(name = "ve_name")
	private String name;
	@Column(name = "ve_company_reg_no")
	private String companyNumber;
	@Column(name = "ve_type")
	private String vendorType;
	@Column(name = "ve_address")
	private String address;
	@Column(name = "ve_country")
	private String country;
	@Column(name = "ve_state")
	private String state;
	@Column(name = "ve_email_address")
	private String email;
	@Column(name = "ve_contact_number")
	private long contactNumber;
	@Column(name = "ve_website")
	private String website;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name = "ve_certificate_issued_date")
	private Date certificateDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name = "ve_certificate_validity_date")
	private Date certificateValidity;
	@Column(name = "ve_year_of_establishment")
	private String yearOfEst;
	@Column(name = "ve_payment_gateway")
	private String paymentGateway;
	@Column(name = "ve_active")
	private boolean active;
	@Column(name = "ve_comment")
	private String comment;
	@Column(name = "ve_image")
	private String image;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public String getVendorType() {
		return vendorType;
	}
	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public Date getCertificateDate() {
		return certificateDate;
	}
	public void setCertificateDate(Date certificateDate) {
		this.certificateDate = certificateDate;
	}
	public Date getCertificateValidity() {
		return certificateValidity;
	}
	public void setCertificateValidity(Date certificateValidity) {
		this.certificateValidity = certificateValidity;
	}
	public String getYearOfEst() {
		return yearOfEst;
	}
	public void setYearOfEst(String yearOfEst) {
		this.yearOfEst = yearOfEst;
	}
	public String getPaymentGateway() {
		return paymentGateway;
	}
	public void setPaymentGateway(String paymentGateway) {
		this.paymentGateway = paymentGateway;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Vendor [id=" + id + ", userId=" + userId + ", name=" + name + ", companyNumber=" + companyNumber
				+ ", vendorType=" + vendorType + ", address=" + address + ", country=" + country + ", state=" + state
				+ ", email=" + email + ", contactNumber=" + contactNumber + ", website=" + website
				+ ", certificateDate=" + certificateDate + ", certificateValidity=" + certificateValidity
				+ ", yearOfEst=" + yearOfEst + ", paymentGateway=" + paymentGateway + ", active=" + active
				+ ", comment=" + comment + ", image=" + image + "]";
	}
	
	
	
}