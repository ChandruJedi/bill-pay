package com.cognizant.signup.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.signup.exception.UserAlreadyExistsException;
import com.cognizant.signup.model.User;
import com.cognizant.signup.repository.UserRepository;
import com.cognizant.signup.security.AppUser;



@Service
public class AppUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepositry;

	
	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepositry = userRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepositry.findByUserId(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found !!!");
		}

//		LOGGER.info("End");

		return new AppUser(user);
	}

	public void signUp(User user) throws UserAlreadyExistsException {
		User users = userRepositry.findByUserId(user.getUserId());
		if (users == null) {
			System.out.println(user);
			user.setPassword(passwordEncoder().encode(user.getPassword()));
			System.out.println(user);
			userRepositry.save(user);
		} else {
			throw new UserAlreadyExistsException("User ALready Exists");
		}
	}

	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
