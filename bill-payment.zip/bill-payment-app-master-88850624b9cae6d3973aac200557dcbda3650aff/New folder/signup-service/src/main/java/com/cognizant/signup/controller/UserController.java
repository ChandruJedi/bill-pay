package com.cognizant.signup.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.signup.exception.UserAlreadyExistsException;
import com.cognizant.signup.service.AppUserDetailsService;
import com.cognizant.signup.service.VendorService;

/**
 * @author 805831
 *
 */
@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	AppUserDetailsService appUserDetailsService;
	
	@Autowired
	VendorService vendorService;

	@PostMapping("/user")
	public void signup(@RequestBody @Valid com.cognizant.signup.model.User user) throws UserAlreadyExistsException {
		System.out.println(user);
		appUserDetailsService.signUp(user);
	}

	@PostMapping("/vendor")
	public void register(@RequestBody @Valid com.cognizant.signup.model.Vendor vendor) {
		System.out.println(vendor);
		vendorService.register(vendor);
	}
}
