
Insert into user values ("admin","abc","zxy",12,"male",9638527410,"Pan123456","123456789","$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK","Admin",""),
("user","abc","zxy",12,"male",9638527410,"Pan123456","123456789","$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK","User",""),
 ("vendor","abc","zxy",12,"male",9638527410,"Pan123456","123456789","$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK","Vendor","");