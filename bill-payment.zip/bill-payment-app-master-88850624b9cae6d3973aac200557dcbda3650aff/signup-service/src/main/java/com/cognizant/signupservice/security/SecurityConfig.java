package com.cognizant.signupservice.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

//	@Autowired
//	private AppUserDetailsService appUserDetailsService;
	
//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.userDetailsService(appUserDetailsService).passwordEncoder(passwordEncoder());
//		auth.inMemoryAuthentication().withUser("admin").password(passwordEncoder().encode("pwd")).roles("ADMIN").and()
//				.withUser("user").password(passwordEncoder().encode("pwd")).roles("USER");
//		System.out.println("I am inside configure");
//	}

//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		BCryptPasswordEncoder xyz = new BCryptPasswordEncoder();
//		System.out.println(xyz);
//		return xyz;
//	}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.cors();
		httpSecurity.csrf().disable().httpBasic()
		.and().authorizeRequests().antMatchers("/menu-items").permitAll()
		.antMatchers("/users").anonymous();
//		.antMatchers("/countries").hasRole("USER")
//				.antMatchers("/countries").hasRole("USER")
//				.antMatchers("/authenticate").hasAnyRole("USER", "ADMIN")
//				.anyRequest().authenticated()
//				.and().addFilter(new JwtAuthorizationFilter(authenticationManager()));
	}

}
