package com.cognizant.signupservice.service;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.signupservice.bean.Role;
import com.cognizant.signupservice.bean.User;
import com.cognizant.signupservice.repository.RoleRepository;
import com.cognizant.signupservice.repository.UserRepository;
import com.cognizant.signupservice.security.AppUser;

@Service
public class AppUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepositry;

	@Autowired
	private RoleRepository roleRepositry;

	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepositry = userRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepositry.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found !!!");
		}

//		LOGGER.info("End");

		return new AppUser(user);
	}

	public void signUp(User user) {
		User users = userRepositry.findByUsername(user.getUsername());
		if (users == null) {
			System.out.println(user);
			user.setPassword(passwordEncoder().encode(user.getPassword()));
			Role role = roleRepositry.findById(2).get();
			user.setRoleList(new HashSet<Role>());
			user.getRoleList().add(role);
			System.out.println(user);
			userRepositry.save(user);
		} else {
			throw new UsernameNotFoundException("User ALready Exists");
		}
	}

	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
