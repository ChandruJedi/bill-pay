package com.cognizant.signupservice.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.signupservice.exception.UserAlreadyExistsException;
import com.cognizant.signupservice.service.AppUserDetailsService;


@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	AppUserDetailsService appUserDetailsService;

	@PostMapping
	public void signup(@RequestBody @Valid com.cognizant.signupservice.bean.User user) throws UserAlreadyExistsException {
		System.out.println(user);
//		boolean isUserExist = inMemoryUserDetailsManager.userExists(user.getUsername());
//		if (isUserExist) {
//			throw new UserAlreadyExistsException();
//		} else {
//			ArrayList<GrantedAuthority> grantedAuthoritiesList = new ArrayList<>();
//			grantedAuthoritiesList.add(new SimpleGrantedAuthority("USER"));
//			inMemoryUserDetailsManager.createUser(User.withUsername(user.getUsername())
//					.password(passwordEncoder().encode(user.getPassword())).roles("USER").build());
//		}
		appUserDetailsService.signUp(user);
	}

	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
