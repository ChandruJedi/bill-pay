package com.cognizant.displaydetailsservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.displaydetailsservice.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	
	User findByUserId(String userId);
	@Query(value = "Select Concat('UserId : ',u.us_user_id,', Name : ',u.us_first_name,' Report : ',u.us_comment) from user u where u.us_comment!='null' ;", nativeQuery = true)
	List<String> gethelp();
}
