package com.cognizant.displaydetailsservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.displaydetailsservice.model.Vendor;
@Repository
public interface VendorRepository extends JpaRepository<Vendor, Integer> {
	
	List<Vendor> findByActive(boolean active);
	List<Vendor> findByUserId(String userId);
	List<Vendor> findByVendorTypeAndActive(String vendorType,boolean active);
}
