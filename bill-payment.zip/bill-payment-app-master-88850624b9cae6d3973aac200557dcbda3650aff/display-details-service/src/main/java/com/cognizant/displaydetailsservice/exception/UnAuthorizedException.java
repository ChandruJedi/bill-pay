package com.cognizant.displaydetailsservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.UNAUTHORIZED,reason="Un Authorized")
public class UnAuthorizedException extends Exception {
	
	public UnAuthorizedException() {
		super();
	}

}
