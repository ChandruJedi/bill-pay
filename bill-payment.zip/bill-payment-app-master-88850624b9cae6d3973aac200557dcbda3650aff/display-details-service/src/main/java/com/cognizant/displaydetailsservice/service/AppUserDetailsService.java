package com.cognizant.displaydetailsservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.displaydetailsservice.exception.UserAlreadyExistsException;
import com.cognizant.displaydetailsservice.model.User;
import com.cognizant.displaydetailsservice.repository.UserRepository;
import com.cognizant.displaydetailsservice.security.AppUser;
@Service
public class AppUserDetailsService implements UserDetailsService {
	@Autowired
	private UserRepository userRepository;

	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}
	
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		User user = userRepository.findByUserId(userId);
		
		if(user==null) {
			throw new UsernameNotFoundException("Username is not found");
		}else {
			return new AppUser(user);
		}
		
	}
	public void signup(User newUser) throws UserAlreadyExistsException {
		System.out.println(newUser);
		User user = userRepository.findByUserId(newUser.getUserId());
		if (user != null) {
			throw new UserAlreadyExistsException();
		} else {
//			newUser.setRoleList(new HashSet<Role>());
//			newUser.getRoleList().add(role);
			userRepository.save(newUser);
		}
	}
}
