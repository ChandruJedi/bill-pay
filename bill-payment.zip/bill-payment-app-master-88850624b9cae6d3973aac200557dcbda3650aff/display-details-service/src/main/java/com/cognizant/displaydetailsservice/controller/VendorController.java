package com.cognizant.displaydetailsservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.displaydetailsservice.model.Vendor;
import com.cognizant.displaydetailsservice.repository.UserRepository;
import com.cognizant.displaydetailsservice.service.VendorService;

@RestController
@RequestMapping("/vendors")
public class VendorController {
	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);
	@Autowired UserRepository userRepository;
	@Autowired
	private VendorService vendorService;
	
	@GetMapping
	public List<Vendor> getInActiveVendor() {
		return vendorService.getInActiveVendor();
	}
	@PostMapping
	public void setVendor(@RequestBody @Valid Vendor vendor){
		vendorService.register(vendor);
	}
	@PutMapping
	public void editVendor(@RequestBody Vendor vendor) {
		vendorService.editVendor(vendor);
	}
	@GetMapping("/{userId}/{id}")
	public Vendor getVendorByID(@PathVariable int id) {
		return vendorService.getVendorById(id);
	}
	@GetMapping("/{userId}")
	public List<Vendor> getVendor(@PathVariable String userId){
		return vendorService.getVendor(userId);
	}
	@GetMapping("/services/{vendorType}")
	public List<Vendor> getVendorServiceType(@PathVariable String vendorType){
		return vendorService.getVendorServiceType(vendorType);
	}
	@PostMapping("/{userId}")
	public void setHelp(@PathVariable String userId, @RequestBody @Valid String comment) {
		System.out.println(userId);
		vendorService.setHelp(userId, comment);
	}
}
