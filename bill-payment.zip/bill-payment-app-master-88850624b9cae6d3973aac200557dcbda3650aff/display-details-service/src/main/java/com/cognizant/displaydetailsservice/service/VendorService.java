package com.cognizant.displaydetailsservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.displaydetailsservice.model.User;
import com.cognizant.displaydetailsservice.model.Vendor;
import com.cognizant.displaydetailsservice.repository.UserRepository;
import com.cognizant.displaydetailsservice.repository.VendorRepository;

@Service
public class VendorService {
	private static final Logger LOGGER = LoggerFactory.getLogger(VendorService.class);
	@Autowired
	private VendorRepository vendorRepositry;
	@Autowired private UserRepository userRepository;

	public List<Vendor> getInActiveVendor() {
		LOGGER.debug("Inside the getinactivevendor method of vendorservice");
		return vendorRepositry.findByActive(false);
	}
	public void setVendor(Vendor vendor) {
		vendorRepositry.save(vendor);
	}
	@Transactional
	public void register(Vendor vendor) {
		vendorRepositry.save(vendor);
	}
	@Transactional
	public void editVendor(Vendor vendor) {
		vendorRepositry.save(vendor);
	}
	@Transactional
	public Vendor getVendorById(int id) {
		return vendorRepositry.findById(id).get();
	}
	@Transactional
	public List<Vendor> getVendor(String userId){
		return vendorRepositry.findByUserId(userId);
	}
	@Transactional
	public List<Vendor> getVendorServiceType(String vendorType){
		return vendorRepositry.findByVendorTypeAndActive(vendorType, true);
	}
	public void setHelp(String userId, String comment) {
		LOGGER.debug("Inside setHelp method of vendorcontroller");
		System.out.println("hiii"+userId);
		User user = userRepository.findByUserId(userId);
		System.out.println(user);
		user.setComment(comment);
		System.out.println(user);
		userRepository.save(user);
	}
	public List<String> getHelp() {
		return userRepository.gethelp();
	}
}
