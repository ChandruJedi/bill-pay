package com.cognizant.displaydetailsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisplayDetailsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayDetailsServiceApplication.class, args);
	}

}
