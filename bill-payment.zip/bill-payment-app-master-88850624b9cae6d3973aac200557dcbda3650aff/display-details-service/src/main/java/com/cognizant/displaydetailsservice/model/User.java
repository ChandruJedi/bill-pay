package com.cognizant.displaydetailsservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
//import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 805834
 *
 */
@Entity
@Table(name = "user")
public class User {
	public static final Logger LOGGER = LoggerFactory.getLogger(User.class);

	@Id
	@Column(name = "us_user_id")
	private String userId;
//	@NotNull
	@Column(name = "us_first_name")
	private String firstName;
//	@NotNull
	@Column(name = "us_last_name")
	private String lastName;
//	@NotNull
	@Column(name = "us_age")
	private int age;
	@Column(name = "us_gender")
	private String gender;
	@Column(name = "us_contact_number")
	private long contactNumber;
	@Column(name = "us_pan")
	private String panNumber;
	@Column(name = "us_aadhar_number")
	private String aadharNumber;
	@Column(name = "us_password")
	private String password;
	@Column(name = "us_role")
	private String role;
	@Column(name = "us_comment")
	private String comment;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String userId, String firstName, String lastName, int age, String gender, int contactNumber, String panNumber,
			String aadharNumber, String password, String role, String comment) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.panNumber = panNumber;
		this.aadharNumber = aadharNumber;
		this.password = password;
		this.role = role;
		this.comment = comment;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public static Logger getLogger() {
		return LOGGER;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", contactNumber=" + contactNumber + ", pan=" + panNumber + ", aadharNumber="
				+ aadharNumber + ", password=" + password + ", role=" + role + ", comment=" + comment + "]";
	}

}
