export interface User{
    userName:string;
    id: number;
    firstName:string;
    lastName:string;
    role:string;
    accessToken:string;
    password?:string;
    age?:any,
    gender?:any,
    contactNumber?:any,
    panNumber?:any,
    aadharNumber?:any,
    userId?:any,
    companyNumber?:any,
    vendorType?:any,
    address?:any,
    country?:any,
    state?:any ,
    email?:any,
    website?:any,
    certificateDate?:any,
    certificateValidity?:any,
    yearOfEst?:any,
    paymentGateway?:any,
}