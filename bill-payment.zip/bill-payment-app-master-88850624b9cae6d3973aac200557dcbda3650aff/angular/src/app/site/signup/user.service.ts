import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseU=environment.baseUrl;
  constructor(private httpClient: HttpClient) { }
  authenticate(userName:string,password:string):Observable<User>{
    return Observable.create((observer:Observer<any>)=>{
      if(userName!=='admin'){
        observer.next({userName,firstName:'Chandru',lastName:'A S',role:'Customer',accsessToken:'JWT-TOKEN'});
      } else {
        observer.next({userName, firstName:'Admin',lastName:'Desk',role:'Admin',accsessToken:'JWT-TOKEN'});
      }
      return null;
    })
  }
  addUser(user:User):Observable<void>{
    return this.httpClient.post<void>(this.baseU+"/users",user);
  }
}
