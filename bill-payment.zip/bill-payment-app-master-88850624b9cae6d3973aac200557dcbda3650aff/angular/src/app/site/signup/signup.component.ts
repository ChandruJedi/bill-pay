import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from './user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  editSign: FormGroup;
  // form: NgForm;
  user: User;
  nextvalue : Boolean = false;
  startDate = new Date(1990, 0, 1);
  userPresent: boolean=false;
  byDefault: boolean=false;
  error: string;
  signupformValidation: boolean;
  vendorForm: FormGroup;
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.editSign = new FormGroup({
      userId:new FormControl(null),
      firstName: new FormControl(null),
      lastName: new FormControl(null),
      password: new FormControl(null),
      cpassword:new FormControl(null),
      age: new FormControl(null),
      gender: new FormControl(null),
      contactNumber: new FormControl(null),
      panNumber:new FormControl(null),
      aadharNumber:new FormControl(null)
    });
    this.vendorForm = new FormGroup({
      name: new FormControl(null),
      companyNumber: new FormControl(null),
      vendorType: new FormControl(null),
      password: new FormControl(null),
      cpassword:new FormControl(null),
      address: new FormControl(null),
      country: new FormControl(null),
      state: new FormControl(null),
      email:new FormControl(null),
      contactNumber:new FormControl(null),
      website:new FormControl(null),
      certificateDate:new FormControl(null),
      certificateValidity:new FormControl(null),
      yearOfEst:new FormControl(null),
      paymentGateway:new FormControl(null),
    });
  }
  get userId() { return this.editSign.get('userId') }
  get firstName() { return this.editSign.get('firstName') }
  get lastName() { return this.editSign.get('lastName'); }
  get password() { return this.editSign.get('password') || this.vendorForm.get('password'); }
  get cpassword() { return this.editSign.get('cpassword') || this.vendorForm.get('cpassword'); }
  get age() { return this.editSign.get('age'); }
  get gender() { return this.editSign.get('gender'); }
  get contactNumber() { return this.editSign.get('contactNumber'); }
  get panNumber() { return this.editSign.get('panNumber'); }
  get aadharNumber() { return this.editSign.get('aadharNumber'); }
  get name() { return this.vendorForm.get('name'); }
  get vendorType() { return this.vendorForm.get('vendorType'); }
  get companyNumber() { return this.vendorForm.get('companyNumber'); }
  get address() { return this.vendorForm.get('address'); }
  get country() { return this.vendorForm.get('country'); }
  get state() { return this.vendorForm.get('state'); }
  get email() { return this.vendorForm.get('email'); }
  get website() { return this.vendorForm.get('website'); }
  get certificateDate() { return this.vendorForm.get('certificateDate'); }
  get certificateValidity() { return this.vendorForm.get('certificateValidity'); }
  get yearOfEst() { return this.vendorForm.get('yearOfEst'); }
  get paymentGateway() { return this.vendorForm.get('paymentGateway'); }

  onSubmit(){
    // this.user=this.editSign.value;
    // console.log(this.editSign);
    // this.userService.addUser(this.user).subscribe(
    //   (data)=>{
    //     this.router.navigate(['/login']);
    //   },
    //   (errorData)=>{
    //     this.error=errorData.error.errorMessage;
    //     this.userPresent=true;
    //   }
    //)
    this.user=this.editSign.value;
    console.log(this.user);
    if (this.editSign.value.password != this.editSign.value.cpassword) {
      this.signupformValidation = true;
    }
    else {
      this.userService.addUser(this.user).subscribe(
        (response) => {
          this.router.navigate(['/login']);
        },
        (responseError) => {
          this.error = responseError.error.errorMessage;
          this.userPresent=true;
        }
       );
    }
   
    }
    next(event){
      console.log("yes");
      this.nextvalue = true;
    }
    clickRadio(event){
      this.byDefault=true;
    }
  }
