import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { UserAuthService } from '../services/user-auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // [x: string]: any;
  isLogin=true;
  authSource:string;
  error: string;
  constructor(private router: Router, private userAuth: UserAuthService, private route: ActivatedRoute, private authService: AuthService,private authenticationService:UserAuthService){} 

  ngOnInit() {
    this.isLogin = !(this.authService.loggedIn);
    this.route.queryParams.subscribe((params:Params)=>{
      this.authSource=params['from'];
    });
  }
  onSubmit(form: NgForm){
    
    const id=form.value.id;
    const userName=form.value.userName;
    const password=form.value.password;
    console.log(userName);
    console.log(userName);
      this.userAuth.authenticate(userName,password).subscribe((data)=>{
      this.authService.logIn(userName,password);
      this.router.navigate(['menu']);
      this.authenticationService.setToken(data.token);
    }, (error) => {
      this.isLogin = false;
      if (error.status == 401) {
        console.log("Invalid Usename/Password");
        this.error = "Invalid Usename/Password";
      }

    });
  }

}
