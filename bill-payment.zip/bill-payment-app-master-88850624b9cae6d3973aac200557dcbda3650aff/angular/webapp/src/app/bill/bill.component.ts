import { Component, OnInit } from '@angular/core';
import { Bill } from '../bill';
import { BillService } from '../bill.service';
import { UserAuthService } from '../services/user-auth.service';
import { DefaultComponent } from '../default/default.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
  bill:Bill
  selectPay: boolean=false;
  constructor(private billService:BillService,private userAuth:UserAuthService, private route:Router) { 
    this.selectPay=this.userAuth.getBillPayment();
  }

  ngOnInit() {
    this.billService.billDetails(this.userAuth.getUser(),this.userAuth.getServiceType()).subscribe(data=>{
      console.log(this.userAuth.getBillPayment());
      this.bill=data;
    })
  }
  payBill(){
    this.route.navigate(['default']);
  }

}
