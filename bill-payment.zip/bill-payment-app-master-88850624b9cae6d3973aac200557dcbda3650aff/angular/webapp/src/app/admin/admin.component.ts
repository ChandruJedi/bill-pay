import { Component, OnInit, HostListener, ElementRef, HostBinding } from '@angular/core';
import { Vendor } from 'src/app/site/vendor';
import { FormGroup, FormControl } from '@angular/forms';
import { VendorService } from 'src/app/services/vendor.service';
import { AuthenticationService } from '../services/authentication-service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  vendors: Vendor;
  selectedDetails: Vendor;
  correction: boolean;
  error: String = '';
  detailDisplay: boolean = false;
  comment: string;
  commentForm: FormGroup;
  _el: ElementRef;
  admin: boolean=false;
  helps: string[];

  constructor(private vendorService: VendorService,private authServ:AuthenticationService) {
    // this.commentForm = new FormGroup({
    //   'comments': new FormControl(null),
    // });

  }

  ngOnInit() {
    this.vendorService.getHelp().subscribe(data => {
      this.helps = data;
    });
    console.log(this.authServ.isLoggedIn)
    this.admin=this.authServ.isLoggedIn;
    this.vendorService.getInActiveVendor().subscribe((data) => {
      this.commentForm = new FormGroup({
        'comments': new FormControl(null),
      });
      this.vendors = data;
    },
      (error) => { this.error = "No Active Vendors Found"; }
    );

  }
  public selectDetails(vendors) {
    this.selectedDetails = vendors;
    this.detailDisplay = true;
    console.log(this.selectedDetails)
  }
  public onAccept(vendor: Vendor) {
    this.detailDisplay = false;
    vendor.active = true;
    this.vendorService.setVendor(vendor).subscribe(data => {
      console.log(vendor);
      this.ngOnInit();
    });
  }

  public onReject(vendor: Vendor) {

    vendor.comment = "Rejected"
    this.vendorService.setVendor(vendor).subscribe(data => {
      console.log(vendor);
      this.ngOnInit();
    });

  }
  public onCorrection(vendor: Vendor) {
    this.correction = true;
  }
  get comments() { return this.commentForm.get('comment'); }
  onSend(vendor: Vendor) {
    console.log(this.commentForm.value.comments);
    console.log(vendor.comment);
    vendor.comment = this.commentForm.value.comments;
    console.log(vendor);
    this.vendorService.setVendor(vendor).subscribe(data => {
      console.log(vendor);
      this.ngOnInit();
    });
  }
  public clicked: boolean = false;

}
