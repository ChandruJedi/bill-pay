import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Vendor } from '../vendor';

import { Router, Params, ActivatedRoute } from '@angular/router';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { UserService } from 'src/app/services/user.service';
import { AuthenticationService } from 'src/app/services/authentication-service.service';
import { VendorService } from 'src/app/services/vendor.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  vendorForm: FormGroup;
  vendor: Vendor;
  signupSuccess: boolean;
  loggedIn:boolean;
  edit: boolean;
  vendorId: any;
  users: boolean=false;
  constructor(private userAuthService: UserAuthService, private userService: UserService, private vendorService:VendorService, private route:ActivatedRoute, private router: Router, private authService: AuthenticationService) { }

  ngOnInit() {
    this.users=this.userAuthService.loggedIn;
    this.vendorForm = new FormGroup({
      userId: new FormControl(this.userAuthService.getUser()),
      name: new FormControl(null, [Validators.required]),
      companyNumber: new FormControl(null, [Validators.required]),
      vendorType: new FormControl(null, [Validators.required]),
      address: new FormControl(null, [Validators.required]),
      country: new FormControl(null, [Validators.required]),
      state: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]),
      contactNumber: new FormControl(null, [Validators.required, Validators.pattern('^[0-9+]*'), Validators.maxLength(13)]),
      website: new FormControl(null, [Validators.required, Validators.pattern('www.[a-z0-9._%+-]+.[a-z]')]),
      certificateDate: new FormControl(null, [Validators.required]),
      certificateValidity: new FormControl(null, [Validators.required]),
      yearOfEst: new FormControl(null, [Validators.required]),
      paymentGateway: new FormControl(null, [Validators.required]),
      active: new FormControl(false),
      image: new FormControl(null),
      comment: new FormControl(null),
    });
    console.log(this.vendorTypes);
    this.edit=this.vendorService.vendorEdit;
    if(this.edit){
    this.route.params.subscribe((params:Params)=>{
      this.vendorId = params['id'];
      this.vendorService.getVendorByID(this.userAuthService.getUser(),this.vendorId).subscribe((vendor:Vendor)=>{
        console.log(vendor);
          if(vendor){
            this.vendorForm.patchValue({
              id:vendor.id,
              name:vendor.name,
              companyNumber:vendor.companyNumber,
              vendorType:vendor.vendorType,
              address:vendor.address,
              country:vendor.country,
              state:vendor.state,
              email:vendor.email,
              contactNumber:vendor.contactNumber,
              website:vendor.website,
              certificateDate:vendor.certificateDate,
              certificateValidity:vendor.certificateValidity,
              yearOfEst:vendor.yearOfEst,
              paymentGateway:vendor.paymentGateway,
              active:vendor.active,
              image:vendor.image,
            });
          }
      })

      })
    }
  }

  get name() { return this.vendorForm.get('name'); }
  get vendorType() { return this.vendorForm.get('vendorType'); }
  get companyNumber() { return this.vendorForm.get('companyNumber'); }
  get address() { return this.vendorForm.get('address'); }
  get country() { return this.vendorForm.get('country'); }
  get state() { return this.vendorForm.get('state'); }
  get email() { return this.vendorForm.get('email'); }
  get website() { return this.vendorForm.get('website'); }
  get contactNumber() { return this.vendorForm
    .get('contactNumber') }
  get certificateDate() { return this.vendorForm.get('certificateDate'); }
  get certificateValidity() { return this.vendorForm.get('certificateValidity'); }
  get yearOfEst() { return this.vendorForm.get('yearOfEst'); }
  get paymentGateway() { return this.vendorForm.get('paymentGateway'); }

  onSubmitVendor() {
    this.vendor = this.vendorForm.value;
    this.vendor.userId = this.userAuthService.getUser();
    // this.vendor.active = false;
    console.log(this.vendor);
    this.userService.register(this.vendor).subscribe(
      (response) => {
        this.signupSuccess=true;
      },
      // (responseError) => {
      //   // this.error = responseError.error.errorMessage;
      //   // this.userPresent = true;
      // }
    );
  }
  onReset() {
    this.vendorForm.reset();
  }
  successValid(event){
    if(this.authService.isLoggedIn){
      this.loggedIn=false;
      this.router.navigate(['vendor']);
    } else{

    this.router.navigate(['login']);
    }
  }
  countryList: Array<any> = [
    {
      name: 'India', state: ['Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli', 'Daman and Diu',
        'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka',
        'Kerala','Lakshadweep','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Puducherry','Punjab','Rajasthan','Sikkim','Tamil Nadu',
        'Tripura','Uttar Pradesh','Uttarakhand','West Bengal'
      ]
    },
    { name: 'Sri Lanka', state: ['Colombo'] },
    { name: 'Bangladesh', state: ['Barisal', 'Chittagong'] },
  ];

  states: Array<any>;

  years: Array<any> = [
    { year: '1999' },
    { year: '2000' }, { year: '2001' }, { year: '2002' }, { year: '2003' }, { year: '2004' }, { year: '2005' }, { year: '2006' }, { year: '2007' }, { year: '2008' }, { year: '2009' }, { year: '2010' }, { year: '2011' }, { year: '2012' }, { year: '2013' }, { year: '2014' }, { year: '2015' }, { year: '2016' }, { year: '2017' }, { year: '2018' }, { year: '2019' }
  ];

  changeCountry(country) {
    this.states = this.countryList.find(nation => nation.name == country).state;
  }

  vendorTypes: Array<any> = [
    { type: 'Electricity' },
    { type: 'Telephone' }, { type: 'DTH' }, { type: 'Insurance' }, { type: 'Tax' }, { type: 'Credit Card' }, { type: 'Loan Account' }, { type: 'Others' }
  ];
}
