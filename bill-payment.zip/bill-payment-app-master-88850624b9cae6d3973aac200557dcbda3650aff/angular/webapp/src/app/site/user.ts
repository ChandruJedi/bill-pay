export interface User{
    userId: string;
    firstName:string;
    lastName:string;
    role:string;
    password:string;
    age?:number,
    gender?:string,
    contactNumber?:any,
    pan?:string,
    aadharNumber?:any,
    comment?:string
}