import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from '../user';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { Vendor } from '../vendor';
import { UserAuthService } from '../../services/user-auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  detailForm: FormGroup;
  userForm: FormGroup;
  // form: NgForm;
  user: User;
  nextStatus: Boolean = false;
  userPresent: boolean = false;
  byDefault: boolean = false;
  error: string;
  signupformValidation: boolean;
  vendorForm: FormGroup;
  newUser: boolean;
  signupSuccess: boolean;
  users: boolean=false;

  constructor(private userService: UserService, private router: Router,private userAuthService: UserAuthService) { }

  ngOnInit() {
    this.users=this.userAuthService.loggedIn;
    console.log(this.users)
    this.detailForm = new FormGroup({
      userId: new FormControl(null, [Validators.required]),
      firstName: new FormControl(null, [Validators.required, Validators.pattern('^[a-z A-Z]*')]),
      lastName: new FormControl(null, [Validators.required, Validators.pattern('^[a-z A-Z]*')]),
      password: new FormControl(null, [Validators.required]),
      confirmPassword: new FormControl(null, [Validators.required]),
      role: new FormControl(null),
      comment:new FormControl(null),
    });

    this.userForm = new FormGroup({
      age: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]*'), Validators.maxLength(3)]),
      gender: new FormControl(null, [Validators.required]),
      contactNumber: new FormControl(null, [Validators.required, Validators.pattern('^[0-9+]*'), Validators.maxLength(13)]),
      pan: new FormControl(null, [Validators.required, Validators.pattern('^[a-zA-Z0-9]*')]), 
      aadharNumber: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]*'), Validators.maxLength(12)]),
     
    });

  }
  get userId() { return this.detailForm.get('userId') }
  get firstName() { return this.detailForm.get('firstName') }
  get lastName() { return this.detailForm.get('lastName') }
  get password() { return this.detailForm.get('password') }
  get confirmPassword() { return this.detailForm.get('confirmPassword') }

  get age() { return this.userForm.get('age'); }
  get gender() { return this.userForm.get('gender'); }
  get contactNumber() { return this.userForm.get('contactNumber') }
  get pan() { return this.userForm.get('pan'); }
  get aadharNumber() { return this.userForm.get('aadharNumber'); }


  isConfirmPasswordValid() {
    if ((this.detailForm.get('password').value != null) && this.detailForm.get('confirmPassword').value != null) {
      if ((this.detailForm.get('password').value != this.detailForm.get('confirmPassword').value)) {
        return true;
      } else {
        return false;
      }
    }
  }

  onSubmit() {
    this.user = this.detailForm.value;
    this.user.role = "User";
    this.user.age = this.userForm.value.age;
    this.user.aadharNumber = this.userForm.value.aadharNumber;
    this.user.contactNumber = this.userForm.value.contactNumber;
    this.user.gender = this.userForm.value.gender;
    this.user.pan = this.userForm.value.panNumber;
    console.log(this.user);
    if (this.detailForm.value.password != this.detailForm.value.confirmPassword) {
      this.signupformValidation = true;
    }
    else {
      this.nextStatus = true;
      this.userService.addUser(this.user).subscribe(
        (response) => {
          this.signupSuccess=true;
          this.userAuthService.setUser(this.detailForm.value.userId);
          this.newUser=true;
        },
        (responseError) => {
          this.error = responseError.error.errorMessage;
          this.userPresent = true;
        }
      );
    }

  }
  successValid(event){
    this.router.navigate(['login']);
  }
  next(event) {
    this.user = this.detailForm.value;
    this.user.role = "Vendor"
    console.log(this.user);
    
    this.userService.addUser(this.user).subscribe(
      (response) => {
        this.nextStatus = true;
        this.router.navigate(['register']);
        this.userAuthService.setUser(this.detailForm.value.userId);
      },
      (responseError) => {
        this.error = responseError.error.errorMessage;
        this.userPresent = true;
      }
    );
  }
  formDisplay() {
    this.byDefault = true;
  }
}

  

