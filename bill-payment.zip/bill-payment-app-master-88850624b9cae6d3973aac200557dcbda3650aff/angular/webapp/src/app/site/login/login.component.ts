import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {AuthenticationService } from '../../services/authentication-service.service';
import { UserAuthService } from '../../services/user-auth.service';
import { Router } from '@angular/router';
import { SignupComponent } from '../signup/signup.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  formValidation: boolean = true;
  error:String='';
  signupSuccess:boolean;
  constructor(private fb: FormBuilder,private router: Router,private authenticationService: AuthenticationService,private userAuthService : UserAuthService) {
    
   }

  ngOnInit() {
    // this.signupSuccess=this.signUp.newUser;
    this.loginForm = this.fb.group({
      username: ['', [
        Validators.required
      ]],
      password: ['', [
        Validators.required
      ]]
    })
  }
  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }
  
  login() {
    this.authenticationService.authenticate(this.username.value, this.password.value).subscribe(data => {
      this.userAuthService.setUser(this.username.value);
      this.userAuthService.setLoggedIn(true);
      this.authenticationService.setToken(data.token);
      console.log(this.userAuthService.getRole());
      this.userAuthService.setRole(data.role);
      if(this.userAuthService.getRole()=="Admin"){
        this.router.navigate(['admin']);
      }
      else if(this.userAuthService.getRole()=="Vendor"){
        this.router.navigate(['vendor']);
      } else {
        this.router.navigate(['default']);
      }
      console.log("Successfully");
      console.log(data.role);
     
    },
      error => {
        this.formValidation = false;
        if (error.status == 401) {
          this.error = "Invalid Username/Password";
        }
    });
  }
}

