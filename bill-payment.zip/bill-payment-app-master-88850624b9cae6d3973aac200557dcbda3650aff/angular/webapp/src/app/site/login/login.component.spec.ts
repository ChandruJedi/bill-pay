import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routes } from 'src/app/app.module';
import { HomeComponent } from 'src/app/home/home.component';
import { SignupComponent } from '../signup/signup.component';
import { RegisterComponent } from '../register/register.component';
import { AppComponent } from 'src/app/app.component';
import { VendorComponent } from 'src/app/vendor/vendor.component';
import { AdminComponent } from 'src/app/admin/admin.component';
import { UserComponent } from 'src/app/user/user.component';
import { BillmapComponent } from 'src/app/billmap/billmap.component';
import { BillComponent } from 'src/app/bill/bill.component';
import { DefaultComponent } from 'src/app/default/default.component';
import { LoginComponent } from './login.component';

fdescribe('LoginComponentComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [   AppComponent,
        LoginComponent,
        VendorComponent,
        RegisterComponent,
        SignupComponent,
        HomeComponent,
        AdminComponent,
        UserComponent,
        BillmapComponent,
        //MappingComponent,
       // BillingComponent,
        BillComponent,
        DefaultComponent,],
      imports:[  FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        RouterModule.forRoot(routes)]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('created a form with username and password input and login button', () => {
    // const fixture = TestBed.createComponent(LoginComponent);
    const usernameContainer = fixture.debugElement.nativeElement.querySelector('#userName');
    const passwordContainer = fixture.debugElement.nativeElement.querySelector('#inputPassword');
    const loginBtnContainer = fixture.debugElement.nativeElement.querySelector('#login');
    expect(usernameContainer).toBeDefined();
    expect(passwordContainer).toBeDefined();
    expect(loginBtnContainer).toBeDefined();
  });
});
