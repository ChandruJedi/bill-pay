import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { DatePipe } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { DefaultComponent } from './default/default.component';
import { RegisterComponent } from './site/register/register.component';
import { AdminComponent } from './admin/admin.component';
import { VendorComponent } from './vendor/vendor.component';
import { UserComponent } from './user/user.component';
import { BillmapComponent } from './billmap/billmap.component';
import { BillComponent } from './bill/bill.component';
import { AuthGuardService } from './auth-guard.service';
import { HelpComponent } from './help/help.component';



export const routes: Routes =
  [
    {path: 'login', component: LoginComponent},
    {path: 'default/login', component: LoginComponent},
    // {path: 'home/login', component: LoginComponent},
    { path: 'signup', component: SignupComponent},
    { path: 'default/signup', component: SignupComponent},

    // { path: 'home/signup', component: SignupComponent},
    { path: 'login/signup', component: SignupComponent},
    { path: 'home', component: HomeComponent,},
    { path:'register', component:RegisterComponent},
    { path:'vendor/register', component:RegisterComponent},
    { path:'admin', component:AdminComponent},
    { path:'vendor', component:VendorComponent},
    { path:'register/:id', component:RegisterComponent},
    { path:'default',component:DefaultComponent},
    { path:'default/default',component:DefaultComponent},
    { path:'bill',component:BillComponent},
    { path:'help',component:HelpComponent},
    { path:'default/help',component:HelpComponent},
    { path:'login/help',component:HelpComponent},
    { path:'signup/help',component:HelpComponent},
    { path:'admin/help',component:HelpComponent},
    { path:'vendor/help',component:HelpComponent},
    { path:'register/help',component:HelpComponent},
    { path:'map', component:BillmapComponent},
    // {path:'',component:DefaultComponent}
    { path: '', redirectTo: 'default', pathMatch: 'full' },

  ];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    DefaultComponent,
    RegisterComponent,
    AdminComponent,
    VendorComponent,
    UserComponent,
    BillmapComponent,
    BillComponent,
    HelpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
