import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserAuthService } from '../services/user-auth.service';
import { VendorService } from '../services/vendor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  helpForm: FormGroup;
  userId: String;
  comment: string;
  constructor(private userAuthService: UserAuthService,
    private vendorService: VendorService,
    private router: Router) { }

  ngOnInit() {
    this.helpForm = new FormGroup({
      userId: new FormControl(this.userAuthService.getUser()),
      comment: new FormControl(null)
    });
  }
  get help() { return this.helpForm.get('help'); }
  onSubmit() {
    this.userId = this.userAuthService.getUser();
    console.log(this.userId);
    this.vendorService.setHelp(this.userId, this.helpForm.value.comment).subscribe((data) => {
     console.log(this.userId);
     console.log(this.helpForm.value.comment)
    });
  }
  ok() {
    if(this.userAuthService.getRole()=="vendor"||this.userAuthService.getRole()=="Vendor") {
    this.router.navigate(['vendor']);
    } else {
      this.router.navigate(['user']);
    }
  }

}
