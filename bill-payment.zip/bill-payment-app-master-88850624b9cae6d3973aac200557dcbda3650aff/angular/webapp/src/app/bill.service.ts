import { Injectable } from '@angular/core';
import { AuthenticationService } from './services/authentication-service.service';
import { Router } from '@angular/router';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Bill } from './bill';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BillService {
  billUrl="http://localhost:8072/payment-gateway/";
  constructor(private authenticationService:AuthenticationService, private httpClient:HttpClient) { }

  billDetails(user:String,serviceType:String){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })    
    };
    return this.httpClient.get<any>(this.billUrl+user+"/"+serviceType,httpOptions);
    
  }
  saveUserDetail(user: String, billDetail: Bill): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    console.log(this.authenticationService.getToken());
    return this.httpClient.post<any>(this.billUrl + user, billDetail, httpOptions);
  }
}
