import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vendor } from '../site/vendor';
import { AuthenticationService } from './authentication-service.service';

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private baseUrl='http://localhost:8071/admin/vendors';
  private vendorUrl='http://localhost:8071/';
  vendorEdit: boolean;
  constructor(private httpClient:HttpClient,private authenticationSerive:AuthenticationService) { }
  getInActiveVendor():Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })    
    };
    console.log(httpOptions);
    return this.httpClient.get(this.baseUrl,httpOptions);
    
  }
  setVendor(vendor:Vendor){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })
    };
    return this.httpClient.post(this.baseUrl,vendor,httpOptions);
  }
  getVendor(user:String):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })    
    };
    return this.httpClient.get<any>(this.vendorUrl+'vendors/'+user,httpOptions);
  }
  getVendorByID(user:String,id:number):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })
    };
    return this.httpClient.get<any>(this.vendorUrl+'vendors/'+user+"/"+id,httpOptions)
  }
  getVendorServiceType(service:String){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })
    };
    return this.httpClient.get<any>(this.vendorUrl+'vendors/services/'+service,httpOptions);
  }
  getHelp(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })
    };
    return this.httpClient.get<any[]>(this.baseUrl + "/help", httpOptions);
  }

  setHelp(userId: String, comment: String): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationSerive.getToken()
      })
    };
    return this.httpClient.post<void>(this.vendorUrl + '/vendors/' + userId, comment, httpOptions);
  }
}
