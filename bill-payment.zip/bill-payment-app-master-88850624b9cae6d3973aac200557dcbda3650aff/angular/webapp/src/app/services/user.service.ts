import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../site/user';
import { Vendor } from '../site/vendor';
import { Bill } from '../bill';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl=environment.baseUrl;
  constructor(private httpClient: HttpClient) { }
  addUser(user:User):Observable<void>{
    return this.httpClient.post<void>("http://localhost:8091"+"/users/user",user);
  }
  register(vendor:Vendor):Observable<void>{
    return this.httpClient.post<void>("http://localhost:8091"+"/users/vendor",vendor);
  }
  // save(detail:Bill,userId:string):Observable<void>{
  //   console.log(detail)
  //   console.log(userId)
   
  //   const httpOptions = {
  //     headers:new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Authorization': 'Bearer' +this.userAuthService.getToken()
  //     })
  //   };
  //   return this.httpClient.post<void>("http://localhost:8098/bill"+"/"+userId,detail,httpOptions)
  // }
}
