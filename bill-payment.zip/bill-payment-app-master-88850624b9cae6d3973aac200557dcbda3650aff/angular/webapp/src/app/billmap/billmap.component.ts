import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserAuthService } from '../services/user-auth.service';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Bill } from '../bill';
import { BillService } from '../bill.service';

@Component({
  selector: 'app-billmap',
  templateUrl: './billmap.component.html',
  styleUrls: ['./billmap.component.css']
})
export class BillmapComponent implements OnInit {

  service: String;
  userDetailService: FormGroup;
  constructor(private userAuthService: UserAuthService,
    private billService: BillService) { }

  ngOnInit() {
    this.service = this.userAuthService.getServiceType();
    this.userDetailService = new FormGroup({
      name: new FormControl(this.service),
      number: new FormControl(null, [Validators.required]),
      amount: new FormControl(null, [Validators.required]),
      date: new FormControl(null, [Validators.required]),
    });
  }
  get number() { return this.userDetailService.get('number')}
  get amount() { return this.userDetailService.get('amount')}
  get date() { return this.userDetailService.get('date')}

  onSubmit() {
    console.log(this.userDetailService.value);
    this.billService.saveUserDetail(this.userAuthService.getUser(), this.userDetailService.value).subscribe(data=>{});
  }


}
