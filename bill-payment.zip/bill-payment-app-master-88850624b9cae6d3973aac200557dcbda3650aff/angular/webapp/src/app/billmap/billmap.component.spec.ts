import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillmapComponent } from './billmap.component';

describe('BillmapComponent', () => {
  let component: BillmapComponent;
  let fixture: ComponentFixture<BillmapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillmapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
