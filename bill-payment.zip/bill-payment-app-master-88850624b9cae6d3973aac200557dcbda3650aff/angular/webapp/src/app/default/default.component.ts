import { Component, OnInit } from '@angular/core';
import { VendorService } from '../services/vendor.service';
import { Vendor } from '../site/vendor';
import { AuthenticationService } from '../services/authentication-service.service';
import { Router } from '@angular/router';
import { UserAuthService } from '../services/user-auth.service';
import { Bill } from '../bill';
import { BillService } from '../bill.service';

@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {
  service:string;
  vendors:Vendor[];
  clickedType: boolean=false;
  selectedType: boolean=false;
  constructor(private vendorService:VendorService,private authenticationService:AuthenticationService, private router:Router,private userAuth:UserAuthService, private billService:BillService) {
   this.clickedType=this.userAuth.getLoggedIn();
    // console.log(this.authenticationService.isLoggedIn);
   }

  ngOnInit() {
  }
  services:Array<any>=[
      {type:'Electricity'},{type:'DTH'},{type:'Credit Card'},{type:'Telephone'},{type:'Insurance'},{type:'Loan'},{type:'Tax'},{type:'Others'}
  ]
  serviceClick(service:string){
    this.service=service;
    this.selectedType=true;
    console.log(this.selectedType);
    console.log(this.clickedType);
    this.userAuth.setServiceType(this.service);
    this.vendorService.getVendorServiceType(service).subscribe((data)=>{
      this.vendors = data;
    }
    )
  }
  payBill(){
    this.userAuth.setBillPayment(true);
    console.log(this.userAuth.getRole())
    if (!this.userAuth.getLoggedIn()) {
      this.router.navigate(['login']);
    } else {
      this.userAuth.setServiceType(this.service);
      this.billService.billDetails(this.userAuth.getUser(), this.service).subscribe(data => {
        if (data == null) {
          this.router.navigate(['map']);
        }
        else {
          this.router.navigate(['bill']);
        }
      });
    }
  }
}
