import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication-service.service';
import { UserAuthService } from '../services/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  clicked: boolean=true;
  isAdmin: boolean=false;
  isVendors: boolean;
  checkNav:boolean=false;
  constructor(private authService: AuthenticationService,private userAuthService:UserAuthService,private router: Router) { 
    
  }

  ngOnInit() {
    
  }
  clickedNav(){
    this.clicked=false;
  }
  authenticated(){
    console.log(this.authService.isLoggedIn);
    this.checkNav=this.userAuthService.getLoggedIn();
    if(this.userAuthService.getRole()=='Vendor'){
      this.isVendors=true;
    }
    console.log(this.userAuthService.getRole())
    return this.checkNav;
  }
  getUser(){
    return this.userAuthService.getUser();
  }
  // adminLogin(){
  //   console.log(this.userAuthService.getRole())
  //   if(this.userAuthService.getRole()=="Admin"){
  //     return this.isAdmin=true;
  //   }
  //   else if(this.userAuthService.getRole()=="Vendor"){
  //     return this.isVendor=true;
  //   }
  // }
  
  signOut(){
    this.userAuthService.setLoggedIn(false);
    this.authService.setToken(null);
    // this.favService.clearFav();
    this.authService.logOut();
    this.router.navigate([this.authService.navUrl]);
    this.userAuthService.setRole(null);
    this.userAuthService.setUser(null);
  }
}
